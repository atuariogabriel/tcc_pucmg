#!/usr/bin/env python
# coding: utf-8

# # Pós-graduação Lato Sensu em Ciência de Dados e Big Data - PUC MG
# 
# ## TCC turma 2020 - Gabriel Fonseca da Silva
# 
# 
# ### Objetivo: desenvolver um algoritmo de machine learning para prever a aprovação de um candidato na prova do ENCCEJA 2019 para obtenção do certificado do ensino fundamental
# 
# ## Dados utilizados:
# 
# ### a) Microdados do ENCCEJA Nacional Regular 2019 dos inscritos que fizeram as provas do ensino fundamental
# ##### https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/encceja
# 
# ### b) Dados de homicídios por UF do ano de 2019 extraídos do DATASUS (grupo CID10 X85-Y09 e Y35-Y36)
# #### http://tabnet.datasus.gov.br/cgi/deftohtm.exe?sim/cnv/ext10uf.def
# 
# ### c) População por UF estimada extraída do DATASUS (estimativas utilizadas pelo TCU)
# #### http://tabnet.datasus.gov.br/cgi/tabcgi.exe?ibge/cnv/poptuf.def
# 
# ### d) Índice de Desenvolvimeno Humano por Estado extraído do Atlas Brasil do IPEA
# #### http://www.atlasbrasil.org.br/
# 
# 
# 
# ## Aplicação: Tratamento dos dados
# 
# ### 1) Importando bibliotecas
# 

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')

import warnings
warnings.filterwarnings("ignore")


# ### 2) Processamento/Tratamento de Dados

# In[2]:


# Carregando os dados

dados_tratados = pd.read_csv("02-dados_filtrados\dados_filtrados.csv", sep = ',', encoding = "ISO-8859-1")

print("\nDimensões: {0}".format(dados_tratados.shape))
print("\nCampos: {0}".format(dados_tratados.keys()))


# #### 2.1) Verificação de dados ausentes

# In[3]:


# Verificação dos "missing values"

print(dados_tratados.isna().sum())


# In[4]:


# Removendo registros dos "missing values" do atributo "NU_IDADE"

dados_tratados.dropna(subset=['NU_IDADE'], inplace=True)
print("\nDimensões: {0}".format(dados_tratados.shape))


# In[5]:


# Removendo os atributos Q09, Q15, Q16, Q17 que possuem mais de 30% de missings e Q32 com 100% de missings  

del dados_tratados['Q09']
del dados_tratados['Q15']
del dados_tratados['Q16']
del dados_tratados['Q17']
del dados_tratados['Q32']

print("\nDimensões: {0}".format(dados_tratados.shape))


# In[6]:


# Verificação dos "missing values"

print(dados_tratados.isna().sum())


# #### 2.2) Verificação e exclusão de dados duplicados

# In[7]:


# Criando o objeto "duplicados" a partir do objeto "dados" sem registros duplicados

duplicados = dados_tratados
duplicados.drop_duplicates()

# Verificando se havia dados duplicados

freq_dados = len(dados_tratados)
freq_duplicados = len(duplicados)


if freq_dados == freq_duplicados:
   print("Não existem registros duplicados")
else:
   print("Existem registros duplicados")


# #### 2.3) Verificação de inconsistências com a variável Q20 (série que deixou de estudar)

# In[8]:


# Espera-se que não haja ninguém que deixou de estudar no ensino médio. Se houver é sinal de inconsistência.
# Os códigos J, K e L são respectivamente: 

# J - 1ª série do ensino médio (antigo 2º grau).
# K - 2ª série do ensino médio (antigo 2º grau).
# L - 3ª série do ensino médio (antigo 2º grau).

freq_Q20=dados_tratados['Q20'].value_counts().sort_index()

if (freq_Q20.J > 0) or (freq_Q20.K > 0) or (freq_Q20.L > 0):
    print("Existem inconsistências - quem deixou de estudar no ensino médio já possui ensino fundamental")
else:
    print("Não há incosnsitências")
    
print(freq_Q20)


# In[9]:


# Excluindo os códigos J, K e L da base de dados

dados_tratados= dados_tratados[(dados_tratados.Q20 != 'J') & (dados_tratados.Q20 != 'K') & (dados_tratados.Q20 != 'L')]

dados_tratados['Q20'].value_counts().sort_index()


# #### 2.4) Criando a variável target

# In[10]:


# Criando um campo que representa a soma do código das 4 provas. Se o resultado for 4 significa aprovação em todas.

dados_tratados['y']=(dados_tratados['IN_APROVADO_MT']+dados_tratados['IN_APROVADO_LC']+
                     dados_tratados['IN_APROVADO_CN']+dados_tratados['IN_APROVADO_CH'])


# Criando a variável target

dados_tratados['target'] = np.where(dados_tratados['y'] == 4, "Aprovado", "Reprovado")


# In[11]:


pd.crosstab(dados_tratados['target'],dados_tratados['y'])


# #### 2.5) Total de registros após o tratamento dos dados

# In[12]:


# Dimensões

print("\nDimensões: {0}".format(dados_tratados.shape))


# In[13]:


# Salvando os dados

dados_tratados.to_csv('03-dados_tratados/dados_tratados.csv',index=False)


# In[ ]:




