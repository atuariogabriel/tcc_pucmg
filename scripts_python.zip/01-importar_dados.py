#!/usr/bin/env python
# coding: utf-8

# # Pós-graduação Lato Sensu em Ciência de Dados e Big Data - PUC MG
# 
# ## TCC turma 2020 - Gabriel Fonseca da Silva
# 
# 
# ### Objetivo: desenvolver um algoritmo de machine learning para prever a aprovação de um candidato na prova do ENCCEJA 2019 para obtenção do certificado do ensino fundamental
# 
# ## Dados utilizados:
# 
# ### a) Microdados do ENCCEJA Nacional Regular 2019 dos inscritos que fizeram as provas do ensino fundamental
# 
# ##### https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/encceja
# 
# ### b) Dados de homicídios por UF do ano de 2019 extraídos do DATASUS (grupo CID10 X85-Y09 e Y35-Y36)
# #### http://tabnet.datasus.gov.br/cgi/deftohtm.exe?sim/cnv/ext10uf.def
# 
# ### c) População por UF estimada extraída do DATASUS (estimativas utilizadas pelo TCU)
# #### http://tabnet.datasus.gov.br/cgi/tabcgi.exe?ibge/cnv/poptuf.def
# 
# ### d) Índice de Desenvolvimeno Humano por Estado extraído do Atlas Brasil do IPEA
# #### http://www.atlasbrasil.org.br/
# 
# 
# 
# ## Aplicação: Importar e filtrar os dados que serão utilizados
# 
# ### 1) Importando bibliotecas
# 

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# ### 2) Carregando os dados
# 
# #### 2.1) Microdados Encceja 2019

# In[2]:


# Importando os dados do Encceja 2019
dados_encceja = pd.read_csv("01-dados_originais/MICRODADOS_ENCCEJA_NACIONAL_REGULAR_2019.csv", sep = ',', 
                            encoding = "ISO-8859-1")

print("\nDimensões: {0}".format(dados_encceja.shape))
print("\nCampos: {0}".format(dados_encceja.keys()))


# In[3]:


# Filtrando os inscritos do ensino fundamental no Encceja 2019 que foram fazer a prova


dados_encceja_v1 = dados_encceja[(dados_encceja.IN_PROVA_MT == 1) & (dados_encceja.TP_PRESENCA_MT == 1) &
                                 (dados_encceja.IN_PROVA_LC == 1) & (dados_encceja.TP_PRESENCA_LC == 1) &
                                 (dados_encceja.IN_PROVA_CN == 1) & (dados_encceja.TP_PRESENCA_CN == 1) &
                                 (dados_encceja.IN_PROVA_CH == 1) & (dados_encceja.TP_PRESENCA_CH == 1) &                                 
                                 (dados_encceja.TP_CERTIFICACAO == 1)]


print("\nDimensões: {0}".format(dados_encceja_v1.shape))


# In[4]:


# Selecionando as variáveis que serão inicialmente utilizados

dados_encceja_v2 = dados_encceja_v1[['NU_INSCRICAO','NU_IDADE','TP_SEXO','SG_UF_PROVA','IN_APROVADO_LC','IN_APROVADO_CN',
                                     'IN_APROVADO_CH','IN_APROVADO_MT','Q01','Q02','Q03','Q04','Q05','Q06','Q07','Q08','Q09',
                                     'Q15','Q16','Q17','Q18','Q19','Q20','Q21','Q31','Q32']]
print("\nDimensões: {0}".format(dados_encceja_v2.shape))
dados_encceja_v2.head(5)


# #### 2.2) Dados de homicídios do DataSus

# In[5]:


# Importando os dados de homicídios do DataSus

homicidios = pd.read_csv("01-dados_originais/datasus_homicidios_2019.csv", sep = ';', skiprows = [0,1,2,3,32,33,34,35,36,37,38,39,40,41,42],
                         encoding = "ISO-8859-1", engine='python')

homicidios = homicidios[['Unidade da Federação','Total']]


# Renomeando as variáveis para retirar acentos e "ç"

homicidios.rename(columns={'Unidade da Federação': 'UF'}, inplace = True)
homicidios.rename(columns={'Total': 'homicidios'}, inplace = True)


# Criando a variável SG_UF_PROVA no mesmo padrão do dataset Encceja 2019

homicidios["SG_UF_PROVA"]=homicidios["UF"]


# Recodificando a variável SG_UF_PROVA para deixá-la no mesmo padrão do dataset Encceja 2019

homicidios["SG_UF_PROVA"]=homicidios["SG_UF_PROVA"].replace(["11 Rondônia","12 Acre","13 Amazonas","14 Roraima","15 Pará",
                                                             "16 Amapá","17 Tocantins","21 Maranhão","22 Piauí","23 Ceará",
                                                             "24 Rio Grande do Norte","25 Paraíba","26 Pernambuco","27 Alagoas",
                                                             "28 Sergipe","29 Bahia","31 Minas Gerais","32 Espírito Santo",
                                                             "33 Rio de Janeiro","35 São Paulo","41 Paraná","42 Santa Catarina",
                                                             "43 Rio Grande do Sul","50 Mato Grosso do Sul","51 Mato Grosso",
                                                             "52 Goiás","53 Distrito Federal"],["RO","AC","AM","RR","PA","AP",
                                                                                                "TO","MA","PI","CE","RN","PB",
                                                                                                "PE","AL","SE","BA","MG","ES",
                                                                                                "RJ","SP","PR","SC","RS","MS",
                                                                                                "MT","GO","DF"])


# Excluindo a variável "UF"
del homicidios['UF']


# Visualizando parte dos dados

print("\nDimensões: {0}".format(homicidios.shape))
print("\nCampos: {0}".format(homicidios.keys()))
homicidios.head(5)


# #### 2.3) Dados de população do DataSus

# In[6]:


# Importando os dados de população do DataSus

populacao = pd.read_csv("01-dados_originais/datasus_populacao_2019.csv", sep = ';', skiprows = [0,1,2,31,32,33,34,35,36,37,38,39,40,41,42,43,],
                        encoding = "ISO-8859-1", engine='python')

# Renomeando as variáveis para retirar acentos e "ç"

populacao.rename(columns={'Unidade da Federação': 'UF'}, inplace = True)
populacao.rename(columns={'População_estimada': 'Populacao'}, inplace = True)


# Criando a variável SG_UF_PROVA no mesmo padrão do dataset Encceja 2019

populacao["SG_UF_PROVA"]=populacao["UF"]


# Recodificando a variável SG_UF_PROVA para deixá-la no mesmo padrão do dataset Encceja 2019

populacao["SG_UF_PROVA"]=populacao["SG_UF_PROVA"].replace(["11 Rondônia","12 Acre","13 Amazonas","14 Roraima","15 Pará",
                                                             "16 Amapá","17 Tocantins","21 Maranhão","22 Piauí","23 Ceará",
                                                             "24 Rio Grande do Norte","25 Paraíba","26 Pernambuco","27 Alagoas",
                                                             "28 Sergipe","29 Bahia","31 Minas Gerais","32 Espírito Santo",
                                                             "33 Rio de Janeiro","35 São Paulo","41 Paraná","42 Santa Catarina",
                                                             "43 Rio Grande do Sul","50 Mato Grosso do Sul","51 Mato Grosso",
                                                             "52 Goiás","53 Distrito Federal"],["RO","AC","AM","RR","PA","AP",
                                                                                                "TO","MA","PI","CE","RN","PB",
                                                                                                "PE","AL","SE","BA","MG","ES",
                                                                                                "RJ","SP","PR","SC","RS","MS",
                                                                                                "MT","GO","DF"])




# Excluindo a variável "UF"
del populacao['UF']


# Visualizando parte dos dados

print("\nDimensões: {0}".format(populacao.shape))
print("\nCampos: {0}".format(populacao.keys()))
populacao.head(5)


# In[7]:


# Juntando os dados de homicidios com a população para calcular a taxa de homicídios

taxa_homicidios = pd.merge(homicidios,populacao, on = 'SG_UF_PROVA')
print("\nDimensões: {0}".format(taxa_homicidios.shape))
print("\nCampos: {0}".format(taxa_homicidios.keys()))
taxa_homicidios.head(5)


# In[8]:


# Calculando a taxa de homicídios por 100 mil habitantes

taxa_homicidios["taxapor100mil"]=round(100000*(taxa_homicidios.homicidios)/(taxa_homicidios.Populacao),2)

taxa_homicidios.head(5)


# #### 2.4) Dados do Índice de Desenvolvimento Humano do IPEA
# 

# In[9]:


# Importando os dados do IDHM

idhm = pd.read_excel("01-dados_originais/data.xlsx", skiprows = [1,29,30,31], usecols=[0, 1])


# Criando a variável SG_UF_PROVA no mesmo padrão do dataset Encceja 2019

idhm["SG_UF_PROVA"]=idhm["Territorialidades"]


# Recodificando a variável SG_UF_PROVA para deixá-la no mesmo padrão do dataset Encceja 2019

idhm["SG_UF_PROVA"]=idhm["SG_UF_PROVA"].replace(["Acre","Alagoas","Amapá","Amazonas","Bahia","Ceará","Distrito Federal",
                                                 "Espírito Santo","Goiás","Maranhão","Mato Grosso do Sul","Mato Grosso",
                                                 "Minas Gerais","Paraíba","Paraná","Pará","Pernambuco","Piauí","Rio de Janeiro",
                                                 "Rio Grande do Norte","Rio Grande do Sul","Rondônia","Roraima",
                                                 "Santa Catarina","São Paulo","Sergipe","Tocantins"],
                                                ["AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MS","MT","MG","PB","PR",
                                                 "PA","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"])


# Renomeando a variável "IDHM 2017" para retirar o espaço

idhm.rename(columns={'IDHM 2017': 'idhm_2017'}, inplace = True)


# Excluindo a variável "Territorialidades"
del idhm['Territorialidades']


# Visualizando parte dos dados

print("\nDimensões: {0}".format(idhm.shape))
print("\nCampos: {0}".format(idhm.keys()))
idhm.head(5)


# #### 2.5) Enriquecimento de dados acrescentando a taxa de homicídios e o IDHM nos microdados do Encceja 2019

# In[10]:


dados1 = pd.merge(dados_encceja_v2,taxa_homicidios, on = 'SG_UF_PROVA')
dados2 = pd.merge(dados1,idhm, on = 'SG_UF_PROVA')

# Visualizando parte dos dados

print("\nDimensões: {0}".format(dados2.shape))
print("\nCampos: {0}".format(dados2.keys()))
dados2.head(5)


# In[11]:


# Salvando os dados

dados2.to_csv('02-dados_filtrados/dados_filtrados.csv',index=False)


# In[ ]:




