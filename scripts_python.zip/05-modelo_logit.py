#!/usr/bin/env python
# coding: utf-8

# # Pós-graduação Lato Sensu em Ciência de Dados e Big Data - PUC MG
# 
# ## TCC turma 2020 - Gabriel Fonseca da Silva
# 
# 
# ### Objetivo: desenvolver um algoritmo de machine learning para prever a aprovação de um candidato na prova do ENCCEJA 2019 para obtenção do certificado do ensino fundamental
# 
# ## Dados utilizados:
# 
# ### a) Microdados do ENCCEJA Nacional Regular 2019 dos inscritos que fizeram as provas do ensino fundamental
# 
# ##### https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/encceja
# 
# ### b) Dados de homicídios por UF do ano de 2019 extraídos do DATASUS (grupo CID10 X85-Y09 e Y35-Y36)
# #### http://tabnet.datasus.gov.br/cgi/deftohtm.exe?sim/cnv/ext10uf.def
# 
# ### c) População por UF estimada extraída do DATASUS (estimativas utilizadas pelo TCU)
# #### http://tabnet.datasus.gov.br/cgi/tabcgi.exe?ibge/cnv/poptuf.def
# 
# ### d) Índice de Desenvolvimeno Humano por Estado extraído do Atlas Brasil do IPEA
# #### http://www.atlasbrasil.org.br/
# 
# 
# 
# ## Aplicação: Regressão Logística
# 
# ### 1) Importando bibliotecas
# 

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
import statsmodels.api as sm
import statsmodels.formula.api as smf

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, roc_curve, classification_report,                            accuracy_score, confusion_matrix, auc
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegressionCV
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_val_predict

from joblib import dump, load
import os

import warnings
warnings.filterwarnings("ignore")


# ### 2) Carregando os dados após a transformação dos dados

# In[2]:


# Importando os dados 

dados = pd.read_csv("05-dados_transformados\dados_dummies.csv", sep = ',', encoding = "ISO-8859-1")

print("\nDimensões: {0}".format(dados.shape))
print("\nCampos: {0}".format(dados.keys()))


# #### 2.1) Separando dados em treino e teste

# In[3]:


# Separando os atributos e o target

## Número de atributos 

k=dados.shape[1]-1


## Selecionando os atributos

X = dados.iloc[:,0:k]


# Selecionando o target

y = dados.iloc[:,k]


# Visualizando o nome dos atributos

print("\nDimensões: {0}".format(X.shape))
print('Nomes dos atributos de X: ')
print("\nCampos: {0}".format(X.keys()))


# In[4]:


# Separando dados de treino e de teste

seed = 7

# Criando os conjuntos de dados de treino e de teste

X_treino, X_teste, y_treino, y_teste = train_test_split(X, y, test_size = 0.30, random_state = seed)

print("\nDimensões X_treino: {0}".format(X_treino.shape))
print("\nDimensões y_treino: {0}".format(y_treino.shape))
print("\nDimensões X_teste:  {0}".format(X_teste.shape))
print("\nDimensões y_teste:  {0}".format(y_teste.shape))


# #### 2.3) Verificando a existência de desbalanceamento das classes

# In[5]:


# Checando o balanceamento das classes

y0 = y_treino

print("\nDistribuição dos dados de treino referentes aos aprovados \n \n0 - Não e 1 - Sim \n")
print(y0.value_counts())
print("\nAprovados são {:.1f}% dos dados de treino.\n".format((y0[y0 == 1].shape[0] / y0.shape[0]) * 100))

sns.countplot(y0);


# ### 3) Gerando o modelo Logit utilizando o Scikit-Learn

# #### 3.1) Gerando o modelo Logit sem cross-validation

# In[6]:


# Gerando o modelo de regressão logística

X0 = X_treino
y0 = y_treino


logit = LogisticRegression(penalty='none', random_state = seed, solver='newton-cg', class_weight='balanced',  
                           fit_intercept=True).fit(X0, y0)


# Extraindo os coeficientes do modelo

intercepto = logit.intercept_
coeficientes = logit.coef_

print('Coeficientes do modelo: \n \n', intercepto, coeficientes)


# Acurácia do modelo

y_pred = logit.predict(X_teste)

print('\n Acurácia: %0.4f' % accuracy_score(y_teste, y_pred))

print("\n Relatório: \n")
print(classification_report(y_teste, y_pred))


# Matriz de confusão

cnf_matrix = confusion_matrix(y_teste, y_pred)

cnf_table = pd.DataFrame(data=cnf_matrix, index=["Aprovado=Não", "Aprovado=Sim"], 
                         columns=["Aprovado(prev)=Não", "Aprovado(prev)=Sim"])


print("\n Matriz de confusão: \n ", cnf_table)


# Curva ROC

print('\n Área abaixo da curva - AUC: %0.4f' % roc_auc_score(y_teste, y_pred))

def plot_roc_curve(y_teste, y_pred, figsize=(10,6)):
    fpr, tpr, _ = roc_curve(y_teste, y_pred)
    plt.figure(figsize=figsize)
    auc_value = roc_auc_score(y_teste, y_pred)
    plt.plot(fpr, tpr, color='blue', label='ROC curve (area = %0.2f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('Taxa de Falso Positivo')
    plt.ylabel('Taxa de Verdadeiro Positivo')
    plt.title('Curva ROC')
    plt.legend()
    plt.show()
    
plot_roc_curve(y_teste, y_pred)    


# In[7]:


# Criando tabela com os valores dos coeficientes do modelo

## Extraindo os nomes dos atributos

nomes=pd.DataFrame(X0.keys())
nomes.rename(columns={0: 'Atributos'}, inplace = True)
nomes.loc[-1] = ['Intercepto']  
nomes.index = nomes.index + 1  
nomes = nomes.sort_index()
nomes=nomes.reset_index()

## Valores dos coeficientes

betas = pd.DataFrame(data=coeficientes).T
betas.rename(columns={0: 'betas'}, inplace = True)
betas.loc[-1] = intercepto  
betas.index = betas.index + 1  
betas = betas.sort_index()
betas=betas.reset_index()

## Tabela

tabela_coef = pd.merge(nomes,betas, on = 'index')
tabela_coef.to_excel('tabelas/coeficientes_logit1.xlsx',index=True,index_label='id')
del tabela_coef['index']


## Calculando a odds ratio (razão de chances)

tabela_coef['razao_chances']=np.exp(tabela_coef['betas'])


print('Coeficientes do modelo: \n' )

tabela_coef


# #### 3.2) Gerando o modelo Logit com cross-validation

# In[8]:


# Separando os dados em 10 blocos e utilizando o mesmo seed

blocos = KFold(10, True, random_state = seed)


# Criando o modelo logístico com cross-validation

logit_cv = LogisticRegressionCV(cv = blocos, random_state = seed, solver='newton-cg', fit_intercept=True,
                              class_weight='balanced').fit(X, y)


# Extraindo os coeficientes do modelo

intercepto_cv = logit_cv.intercept_
coeficientes_cv = logit_cv.coef_

print('Coeficientes do modelo: \n \n', intercepto_cv, coeficientes_cv)


# Acurácia do modelo

y_pred_cv = logit_cv.predict(X)


print('\n Acurácia: %0.4f' % accuracy_score(y, y_pred_cv))

print("\n Relatório: \n")
print(classification_report(y, y_pred_cv))


# Matriz de confusão

cnf_matrix_cv = confusion_matrix(y, y_pred_cv)
cnf_table_cv = pd.DataFrame(data=cnf_matrix, index=["Aprovado=Não", "Aprovado=Sim"], 
                         columns=["Aprovado(prev)=Não", "Aprovado(prev)=Sim"])

print("\n Matriz de confusão: \n ", cnf_table_cv)


# Curva ROC

print('\n Área abaixo da curva - AUC: %0.4f' % roc_auc_score(y, y_pred_cv))

def plot_roc_curve(y_teste, y_pred_cv, figsize=(10,6)):
    fpr_cv, tpr_cv, _ = roc_curve(y, y_pred_cv)
    plt.figure(figsize=figsize)
    auc_value_cv = roc_auc_score(y, y_pred_cv)
    plt.plot(fpr_cv, tpr_cv, color='blue', label='ROC curve (area = %0.2f)' % auc_value_cv)
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('Taxa de Falso Positivo')
    plt.ylabel('Taxa de Verdadeiro Positivo')
    plt.title('Curva ROC')
    plt.legend()
    plt.show()
    
plot_roc_curve(y, y_pred_cv)


# In[9]:


# Criando tabela com os valores dos coeficientes_cv do modelo

## Extraindo os nomes_cv dos atributos

nomes_cv=pd.DataFrame(X.keys())
nomes_cv.rename(columns={0: 'Atributos'}, inplace = True)
nomes_cv.loc[-1] = ['Intercepto']  
nomes_cv.index = nomes_cv.index + 1  
nomes_cv = nomes_cv.sort_index()
nomes_cv=nomes_cv.reset_index()

## Valores dos coeficientes_cv

betas_cv = pd.DataFrame(data=coeficientes_cv).T
betas_cv.rename(columns={0: 'betas_cv'}, inplace = True)
betas_cv.loc[-1] = intercepto_cv  
betas_cv.index = betas_cv.index + 1  
betas_cv = betas_cv.sort_index()
betas_cv=betas_cv.reset_index()

## Tabela

tabela_coef_cv = pd.merge(nomes_cv,betas_cv, on = 'index')
tabela_coef_cv.to_excel('tabelas/coeficientes_logitcv.xlsx',index=True,index_label='id')
del tabela_coef_cv['index']


## Calculando a odds ratio (razão de chances)

tabela_coef_cv['razao_chances']=np.exp(tabela_coef_cv['betas_cv'])


print('Coeficientes do modelo: \n' )

tabela_coef_cv


# ### 4) Salvando os modelos gerados
# 

# In[10]:


# Alterando o diretório dos dados

os.chdir("06-modelos")


# Salvando o modelo logit

dump(logit, 'modelo_logit.joblib')


# Salvando o modelo logit com Cross-Validation

dump(logit_cv, 'modelo_logitcrossvalid.joblib') 


# In[ ]:




