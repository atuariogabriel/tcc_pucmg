#!/usr/bin/env python
# coding: utf-8

# # Pós-graduação Lato Sensu em Ciência de Dados e Big Data - PUC MG
# 
# ## TCC turma 2020 - Gabriel Fonseca da Silva
# 
# 
# ### Objetivo: desenvolver um algoritmo de machine learning para prever a aprovação de um candidato na prova  do ENCCEJA 2019 para obtenção do certificado do ensino fundamental
# 
# ## Dados utilizados:
# 
# ### a) Microdados do ENCCEJA Nacional Regular 2019 dos inscritos que fizeram as provas do ensino fundamental
# 
# ##### https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/encceja
# 
# ### b) Dados de homicídios por UF do ano de 2019 extraídos do DATASUS (grupo CID10 X85-Y09 e Y35-Y36)
# #### http://tabnet.datasus.gov.br/cgi/deftohtm.exe?sim/cnv/ext10uf.def
# 
# ### c) População por UF estimada extraída do DATASUS (estimativas utilizadas pelo TCU)
# #### http://tabnet.datasus.gov.br/cgi/tabcgi.exe?ibge/cnv/poptuf.def
# 
# ### d) Índice de Desenvolvimeno Humano por Estado extraído do Atlas Brasil do IPEA
# #### http://www.atlasbrasil.org.br/
# 
# 
# 
# ## Aplicação: Transformação dos Dados
# 
# ### 1) Importando bibliotecas
# 

# In[1]:


import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")


# ### 2) Carregando os dados após a análise exploratória de dados

# In[2]:


# Importando os dados após a análise exploratória de dados

dados = pd.read_csv("04-dados_apos_analise\dados_apos_analise.csv", sep = ',', encoding = "ISO-8859-1")

print("\nDimensões: {0}".format(dados.shape))
print("\nCampos: {0}".format(dados.keys()))


# ### 3) Transformando os dados em dummies

# #### Transformação para Árvore de Decisão e Naïve Bayes

# In[3]:


# Transformando as variáveis categóricas em dummies

nomes=np.array(dados.keys())
dados_arvore = pd.get_dummies(dados[nomes])


# Gerando tabela de contagens dos valores "true"

print("\nDimensões: {0}".format(dados_arvore.shape))
print('\nContagem dos valores 1 de cada dummy: ')

valor_true=pd.DataFrame(dados_arvore.agg('sum'))
valor_true=valor_true.reset_index()
valor_true.rename(columns={0: 'Valor 1'}, inplace = True)
valor_true.rename(columns={'index': 'Dummies'}, inplace = True)
valor_true


# In[4]:


# Eliminando as dummies redundantes

del dados_arvore ['genero_Masculino']
del dados_arvore ['target_Reprovado']
del dados_arvore ['moradia_pessoas_B-Mais de 3 pessoas']
del dados_arvore ['moradia_tipo_B-Alugada/cedida']
del dados_arvore ['moradia_local_A-Zona não urbana']
del dados_arvore ['trabalha_B-Não']
del dados_arvore ['eja_B-Não']


# Gerando tabela de contagens dos valores "true" após eliminar as redundantes

print("\nDimensões: {0}".format(dados_arvore.shape))
print('\nContagem dos valores 1 de cada dummy: ')

valor_true=pd.DataFrame(dados_arvore.agg('sum'))
valor_true=valor_true.reset_index()
valor_true.rename(columns={0: 'Valor 1'}, inplace = True)
valor_true.rename(columns={'index': 'Dummies'}, inplace = True)
valor_true


# #### Transformação para Regressão Logística

# In[5]:


# Transformando as variáveis categóricas em dummies

nomes=np.array(dados.keys())
dados_dummies = pd.get_dummies(dados[nomes])


# Gerando tabela de contagens dos valores "true"

print("\nDimensões: {0}".format(dados_dummies.shape))
print('\nContagem dos valores 1 de cada dummy: ')

valor_true=pd.DataFrame(dados_dummies.agg('sum'))
valor_true=valor_true.reset_index()
valor_true.rename(columns={0: 'Valor 1'}, inplace = True)
valor_true.rename(columns={'index': 'Dummies'}, inplace = True)
valor_true


# In[6]:


# Eliminando uma das categorias de acordo com os seguintes critérios:

# a primeira quando era do tipo ordinal
# a de menor frequência quando não era do tipo ordinal
# a afirmativa negativa quando só havia duas opções

del dados_dummies ['genero_Masculino']
del dados_dummies ['moradia_pessoas_B-Mais de 3 pessoas']
del dados_dummies ['moradia_tipo_B-Alugada/cedida']
del dados_dummies ['moradia_local_A-Zona não urbana']
del dados_dummies ['trabalha_B-Não']
del dados_dummies ['eja_B-Não']
del dados_dummies ['target_Reprovado']
del dados_dummies ['escolaridade_pai_A-Não estudou/não sabe']
del dados_dummies ['escolaridade_mae_A-Não estudou/não sabe']
del dados_dummies ['renda_propria_A-Nenhuma renda']
del dados_dummies ['reprovou_A-Nenhuma vez']
del dados_dummies ['motivo_estudo_D-Outro motivo']
del dados_dummies ['serie_estudo_A-4ª série ou antes']
del dados_dummies ['idade_estudo_A-Não deixou de frequentar']
del dados_dummies ['faixa_etaria_A-Até 20']
del dados_dummies ['taxa_homicidios_A-De 7,3 a 13,7']
del dados_dummies ['idhm_A-Até 0,766']
del dados_dummies ['regiao_Norte']

print("\nDimensões: {0}".format(dados_dummies.shape))

valor_true=pd.DataFrame(dados_dummies.agg('sum'))
valor_true=valor_true.reset_index()
valor_true.rename(columns={0: 'Valor 1'}, inplace = True)
valor_true.rename(columns={'index': 'Dummies'}, inplace = True)
valor_true.to_excel('tabelas/tabela_dummies.xlsx',index=True,index_label='id')
valor_true


# ### 4) Salvando os dados transformados

# In[7]:


# Salvando os dados para árvore de decisão e Naive Bayes

dados_arvore.to_csv('05-dados_transformados/dados_arvore.csv',index=False, encoding = "ISO-8859-1")


# In[8]:


# Salvando os dados para Regressão Logística

dados_dummies.to_csv('05-dados_transformados/dados_dummies.csv',index=False, encoding = "ISO-8859-1")


# In[ ]:




