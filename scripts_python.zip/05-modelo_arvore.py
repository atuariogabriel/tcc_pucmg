#!/usr/bin/env python
# coding: utf-8

# # Pós-graduação Lato Sensu em Ciência de Dados e Big Data - PUC MG
# 
# ## TCC turma 2020 - Gabriel Fonseca da Silva
# 
# 
# ### Objetivo: desenvolver um algoritmo de machine learning para prever a aprovação de um candidato na prova  do ENCCEJA 2019 para obtenção do certificado do ensino fundamental
# 
# ## Dados utilizados:
# 
# ### a) Microdados do ENCCEJA Nacional Regular 2019 dos inscritos que fizeram as provas do ensino fundamental
# 
# ##### https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/encceja
# 
# ### b) Dados de homicídios por UF do ano de 2019 extraídos do DATASUS (grupo CID10 X85-Y09 e Y35-Y36)
# #### http://tabnet.datasus.gov.br/cgi/deftohtm.exe?sim/cnv/ext10uf.def
# 
# ### c) População por UF estimada extraída do DATASUS (estimativas utilizadas pelo TCU)
# #### http://tabnet.datasus.gov.br/cgi/tabcgi.exe?ibge/cnv/poptuf.def
# 
# ### d) Índice de Desenvolvimeno Humano por Estado extraído do Atlas Brasil do IPEA
# #### http://www.atlasbrasil.org.br/
# 
# 
# 
# ## Aplicação: Árvore de Decisão
# 
# ### 1) Importando bibliotecas
# 

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')

from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_extraction import DictVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn import tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, roc_curve, classification_report,                            accuracy_score, confusion_matrix, auc
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_val_predict
from sklearn.model_selection import GridSearchCV
from sklearn.tree import export_text

from joblib import dump, load
import graphviz
import os

import warnings
warnings.filterwarnings("ignore")


# ### 2) Carregando os dados transformados

# In[2]:


# Importando os dados após a análise exploratória de dados

dados = pd.read_csv("05-dados_transformados\dados_arvore.csv", sep = ',', encoding = "ISO-8859-1")

print("\nDimensões: {0}".format(dados.shape))
print("\nCampos: {0}".format(dados.keys()))


# #### 2.1) Separando o target

# In[3]:


# Separando os atributos e o target

## Número de atributos 

k=dados.shape[1]-1


## Selecionando os atributos

X0 = dados.iloc[:,0:k]


# Selecionando o target

y0 = dados.iloc[:,k]


# Visualizando o nome dos atributos

print("\nDimensões: {0}".format(X0.shape))
print('Nomes dos atributos de X: ')
print("\nCampos: {0}".format(X0.keys()))


# #### 2.2) Separando dados em treino e teste

# In[4]:


# Criando os conjuntos de dados de treino e de teste

seed = 7

X_treino, X_teste, y_treino, y_teste = train_test_split(X0, y0, test_size = 0.30, random_state = seed)

print("\nDimensões: {0}".format(X_treino.shape))
print("\nDimensões: {0}".format(y_treino.shape))
print("\nDimensões: {0}".format(X_teste.shape))
print("\nDimensões: {0}".format(y_teste.shape))


# ### 3) Indução do modelo

# #### 3.1) Árvore de decisão utilizando entropia

# In[5]:


# indução do modelo

treeAprov = DecisionTreeClassifier(random_state=seed, criterion='entropy', class_weight='balanced',max_depth=7)
treeAprov = treeAprov.fit(X_treino, y_treino)

y_pred = treeAprov.predict(X_teste)

print(classification_report(y_teste, y_pred))

cnf_matrix = confusion_matrix(y_teste, y_pred)
cnf_table = pd.DataFrame(data=cnf_matrix, index=["Aprovado=Não", "Aprovado=Sim"], 
                         columns=["Aprovado(prev)=Não", "Aprovado(prev)=Sim"])
print(cnf_table)

print("\n Acurácia: \n", accuracy_score(y_teste, y_pred))


# Curva ROC

print('\n Área abaixo da curva - AUC: %0.4f' % roc_auc_score(y_teste, y_pred))

def plot_roc_curve(y_teste, y_pred, figsize=(10,6)):
    fpr, tpr, _ = roc_curve(y_teste, y_pred)
    plt.figure(figsize=figsize)
    auc_value = roc_auc_score(y_teste, y_pred)
    plt.plot(fpr, tpr, color='blue', label='ROC curve (area = %0.2f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('Taxa de Falso Positivo')
    plt.ylabel('Taxa de Verdadeiro Positivo')
    plt.title('Curva ROC')
    plt.legend()
    plt.show()
    
plot_roc_curve(y_teste, y_pred)    


# #### 3.2) Árvore de decisão utilizando Gini

# In[6]:


# indução do modelo

treeAprov2 = DecisionTreeClassifier(random_state=seed, criterion='gini', class_weight='balanced', max_depth=7)
treeAprov2 = treeAprov2.fit(X_treino, y_treino)

y_pred2 = treeAprov2.predict(X_teste)

print(classification_report(y_teste, y_pred2))

cnf_matrix2 = confusion_matrix(y_teste, y_pred2)
cnf_table2 = pd.DataFrame(data=cnf_matrix2, index=["Aprovado=Não", "Aprovado=Sim"], 
                         columns=["Aprovado(prev)=Não", "Aprovado(prev)=Sim"])
print(cnf_table2)

print("\n Acurácia: \n", accuracy_score(y_teste, y_pred2))

# Curva ROC

print('\n Área abaixo da curva - AUC: %0.4f' % roc_auc_score(y_teste, y_pred2))

def plot_roc_curve(y_teste, y_pred2, figsize=(10,6)):
    fpr, tpr, _ = roc_curve(y_teste, y_pred2)
    plt.figure(figsize=figsize)
    auc_value = roc_auc_score(y_teste, y_pred2)
    plt.plot(fpr, tpr, color='blue', label='ROC curve (area = %0.2f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('Taxa de Falso Positivo')
    plt.ylabel('Taxa de Verdadeiro Positivo')
    plt.title('Curva ROC')
    plt.legend()
    plt.show()
    
plot_roc_curve(y_teste, y_pred2)    


# #### 3.3) Árvore de decisão utilizando GridSearch com Cross-Validation

# In[7]:


# indução do modelo

treeAprov3 = DecisionTreeClassifier(random_state=seed, class_weight='balanced')


# Hiperparâmetros a serem testados

parametros={'criterion':('gini','entropy'), 'min_samples_leaf':[1,2,3],'max_depth':[1,2,3,4,5,6,7,8,9,10,'None'] }

treeAprov3_grid=GridSearchCV(treeAprov3, param_grid=parametros)


# Fazendo a previsão

y_pred3 = treeAprov3_grid.fit(X_treino, y_treino).predict(X_teste)


# Encontrando os melhores hiperparâmetros

print('\n Melhores hiperparâmetros segundo o GridSearch: \n')
print(treeAprov3_grid.best_params_,'\n')


# Relatório

print(classification_report(y_teste, y_pred3))

cnf_matrix3 = confusion_matrix(y_teste, y_pred3)
cnf_table3 = pd.DataFrame(data=cnf_matrix3, index=["Aprovado=Não", "Aprovado=Sim"], 
                         columns=["Aprovado(prev)=Não", "Aprovado(prev)=Sim"])
print(cnf_table3)

print("\n Acurácia: \n", accuracy_score(y_teste, y_pred3))


# Curva ROC

print('\n Área abaixo da curva - AUC: %0.4f' % roc_auc_score(y_teste, y_pred3))

def plot_roc_curve(y_teste, y_pred3, figsize=(10,6)):
    fpr, tpr, _ = roc_curve(y_teste, y_pred3)
    plt.figure(figsize=figsize)
    auc_value = roc_auc_score(y_teste, y_pred3)
    plt.plot(fpr, tpr, color='blue', label='ROC curve (area = %0.2f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')
    plt.xlabel('Taxa de Falso Positivo')
    plt.ylabel('Taxa de Verdadeiro Positivo')
    plt.title('Curva ROC')
    plt.legend()
    plt.show()
    
plot_roc_curve(y_teste, y_pred3)    


# #### 3.4) Gerando o melhor modelo

# In[8]:


# Aplicando o modelo com os melhores hiperparâmetros

arvore = DecisionTreeClassifier(random_state=seed, criterion='entropy', class_weight='balanced', 
                                min_samples_leaf=2, max_depth=7)

arvore = arvore.fit(X_treino, y_treino)


# In[9]:


# Criando tabela com os valores dos importances do modelo

## Extraindo os nomes dos atributos

nomes=pd.DataFrame(X0.keys())
nomes.rename(columns={0: 'Atributos'}, inplace = True)
nomes=nomes.reset_index()

## Valores das feature importances

importances=arvore.feature_importances_ 

betas = pd.DataFrame(data=importances)
betas.rename(columns={0: 'Feature Importance'}, inplace = True)

betas=betas.reset_index()

## Tabela

tabela_importances = pd.merge(nomes,betas, on = 'index')
del tabela_importances['index']
tabela_importances=tabela_importances.sort_values(by=['Feature Importance'], ascending=False)
tabela_importances['Ranking']=np.arange(k) # k é o número de atributos definido no item 2.1
tabela_importances['Ranking']=tabela_importances['Ranking']+1  # Fazendo o ranking começar do nº 1

tabela_importances.to_excel('tabelas/arvore_importances.xlsx',index=True,index_label='id') # salvando a tabela

print('Feature Importances: \n' )

tabela_importances


# ### 4) Salvando o melhor modelo gerado

# In[10]:


# Alterando o diretório dos dados

os.chdir("06-modelos")


# Salvando o modelo decision tree com os melhores hiperparâmetros

dump(arvore, 'modelo_decisiontree.joblib')


# Salvando a árvore

with open('saida_arvore.txt', 'w') as arquivo:
    r = export_text(arvore)
    print(r, file=arquivo)


# In[ ]:




